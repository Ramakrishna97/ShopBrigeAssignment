using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ShopBridge_Assignment.BL;
using ShopBridge_Assignment.Controllers;
using ShopBridge_Assignment.Entities;
using System;
using System.Threading.Tasks;

namespace UnitTestProject2
{
    [TestClass]
    public class ProductsControllerTests
    {
        Mock<IProductService> productService = null;
        ProductsController controller = null;

        [TestInitialize]
        public void Initialization()
        {
            productService = new Mock<IProductService>();
            controller = new ProductsController();
        }
       

        [TestMethod]
        public void GetTest()
        {
            productService.Setup(x => x.GetAllProductDetails<ProductDetails>()).Returns(new System.Collections.Generic.List<ProductDetails>()
            {
               new ProductDetails()
               {
                ProductDesc = "Prodict1",
                Price = 1000,
                ProductName = "P1",
                ProductNbr=1,
                Quantity=1,
                ActiveInd="Y",
                CreatedBy="admin",
                CreatedOn=DateTime.Now,
                UpdatedBy="admin",
                UpdatedOn=DateTime.Now
                },
               new ProductDetails()
               {
                ProductDesc = "Prodict11",
                Price = 1000,
                ProductName = "P11",
                ProductNbr=11,
                Quantity=17,
                ActiveInd="Y",
                CreatedBy="admin",
                CreatedOn=DateTime.Now,
                UpdatedBy="admin",
                UpdatedOn=DateTime.Now
                }
            });
            controller = new ProductsController(productService.Object);
            var result=controller.Get();
            Assert.IsNotNull(result);

            productService.Setup(x => x.GetAllProductDetails<ProductDetails>()).Returns<IAsyncResult>(null);
            controller = new ProductsController(productService.Object);
            result = controller.Get();
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void PostTest()
        {
            productService.Setup(x => x.SaveProductDetailsAsync<ProductDetails>(It.IsAny<ProductDetails>())).Returns(()=>Task.FromResult(1));
            var request = new ProductDetails()
            {
                ProductDesc = "Prodict1",
                Price = 1000,
                ProductName = "P1"
            };
            controller = new ProductsController(productService.Object);
            var result = controller.Post(request);
            Assert.IsNotNull(result);

            //Product Not Saved 
            productService.Setup(x => x.SaveProductDetailsAsync<ProductDetails>(It.IsAny<ProductDetails>())).Returns(() => Task.FromResult(0));
            controller = new ProductsController(productService.Object);
            result = controller.Post(request);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void PutTest()
        {
            productService.Setup(x => x.UpdateProductDetailsAsync<ProductDetails>(It.IsAny<long>(),It.IsAny<ProductDetails>())).Returns(() => Task.FromResult(1));
            var request = new ProductDetails()
            {
                ProductDesc = "Prodict1",
                Price = 1000,
                ProductName = "P1",
                ProductNbr=1
                
            };
            controller = new ProductsController(productService.Object);
            var result = controller.Put(1,request);
            Assert.IsNotNull(result);

            //For Product Not Found 
            productService.Setup(x => x.Delete<ProductDetails>(It.IsAny<long>())).Returns(() => Task.FromResult(0));
            controller = new ProductsController(productService.Object);
            result = controller.Put(1, request);
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void Delete()
        {
            productService.Setup(x => x.Delete<ProductDetails>(It.IsAny<long>())).Returns(() => Task.FromResult(1));
            controller = new ProductsController(productService.Object);
            var result = controller.Delete(2);
            Assert.IsNotNull(result);

            //For Product Not Found 
            productService.Setup(x => x.Delete<ProductDetails>(It.IsAny<long>())).Returns(() => Task.FromResult(0));
            controller = new ProductsController(productService.Object);
            result = controller.Delete(2);
            Assert.IsNotNull(result);
        }
    }
}
