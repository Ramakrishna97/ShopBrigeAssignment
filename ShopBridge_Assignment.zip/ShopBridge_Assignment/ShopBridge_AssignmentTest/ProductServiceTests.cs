﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ShopBridge_Assignment.BL;
using ShopBridge_Assignment.Entities;
using ShopBridge_Assignment.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTestProject2
{
    [TestClass]

    public class ProductServiceTests
    {
        Mock<IRepository> repository = null;
        ProductService service = null;

        [TestInitialize]
        public void Initialization()
        {
            repository = new Mock<IRepository>();
            service = new ProductService(repository.Object);
        }

        [TestMethod]
        public void SaveProductDetailsAsyncTest()
        {
            var request = new ProductDetails()
            {
                ProductDesc = "Prodict1",
                Price = 1000,
                ProductName = "P1"
            };
            var res= service.SaveProductDetailsAsync(request);
            Assert.IsNotNull(res);

        }

        [TestMethod]
        public void UpdateProductDetailsAsyncTest()
        {
            var request = new ProductDetails()
            {
                ProductDesc = "Prodict1",
                Price = 1000,
                ProductName = "P1"
            };
            var res = service.UpdateProductDetailsAsync(1,request);
            Assert.IsNotNull(res);
        }

        [TestMethod]
        public void DeleteTest()
        {
            
            var res = service.Delete<ProductDetails>(1);
            Assert.IsNotNull(res);
        }

        

    }
}
