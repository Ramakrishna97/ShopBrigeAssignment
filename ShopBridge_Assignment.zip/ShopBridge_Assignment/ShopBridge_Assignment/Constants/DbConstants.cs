﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_Assignment.Constants
{
    
    public static class DbConstants
    {
        public const string Yes = "Y";
        public const string No = "N";
        public const string Admin = "Admin";
        public const string SqlConnectionString = "SQLCONNECTIONSTRING";
        public const string UpdatedOn = "UpdatedOn";
        public const string UpdatedBy = "UpdatedBy";
        public const string CreatedOn = "CreatedOn";
        public const string CreatedBy = "CreatedBy";
        public const string ActiveInd = "ActiveInd";
    }
    public static class TableConstants
    {
        public const string ProductDetails = "ProductDetails";
    }

    public static class SchemaConstants
    {
        public const string ShopBridge = "dbo";
    }

    public static class MsgConstants
    {
        public const string DataNotSaved = "Data Not Saved";
        public const string ProductNotFound = "Product Not Found";
        public const string ContentType = "text/html";
    }
}
