﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_Assignment.Constants
{
    
    public static class DbConstants
    {
        public const string Yes = "Y";
        public const string No = "N";
        public const string Admin = "Admin";
    }
    public class TableConstants
    {
        public const string ProductDetails = "ProductDetails";
    }

    public class SchemaConstants
    {
        public const string ShopBridge = "dbo";
    }
}
