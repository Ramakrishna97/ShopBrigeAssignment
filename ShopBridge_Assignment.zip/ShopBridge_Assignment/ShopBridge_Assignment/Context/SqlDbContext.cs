﻿using Microsoft.EntityFrameworkCore;
using ShopBridge_Assignment.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_Assignment.Context
{
    
    public class SqlDbContext : DbContext, ISqlDbContext
    {
        public SqlDbContext()
        {

        }
        public SqlDbContext(DbContextOptions options) : base(options)
        { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source = (localdb)\ProjectsV13; Integrated Security = true; Initial Catalog = ShopBridge;");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<ProductDetails> ProductDetails { get; set; }
    }
}
