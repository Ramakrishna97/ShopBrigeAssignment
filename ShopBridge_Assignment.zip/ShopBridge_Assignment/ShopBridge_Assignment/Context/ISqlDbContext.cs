﻿using Microsoft.EntityFrameworkCore;
using ShopBridge_Assignment.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_Assignment.Context
{
    public interface ISqlDbContext
    {
        DbSet<ProductDetails> ProductDetails { get; set; }
    }
}
