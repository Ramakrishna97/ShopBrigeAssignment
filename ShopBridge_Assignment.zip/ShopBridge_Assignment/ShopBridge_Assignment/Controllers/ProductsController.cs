﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ShopBridge_Assignment.BL;
using ShopBridge_Assignment.Entities;
using ShopBridge_Assignment.Filters;

namespace ShopBridge_Assignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {

        IProductService productService = null;

        #region Constructor
        public ProductsController()
        {
            productService = new ProductService(new Repository.Repository(new Context.SqlDbContext()));
        }

        public ProductsController(IProductService _productService)
        {
            productService = _productService;
        } 
        #endregion

        #region PublicMethods
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<ProductDetails>> Get()
        {
            var productsList = productService.GetAllProductDetails<ProductDetails>();
            if (productsList != null)
            {
                return Ok(productsList);
            }
            else
            {
                return new List<ProductDetails>();
            }
        }

        // POST api/Products
        [ServiceFilter(typeof(ValidateModelAttribute))]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] ProductDetails productDetails)
        {

            var product = await productService.SaveProductDetailsAsync(productDetails);
            if (product == 1)
            {
                return Ok(product);
            }
            else
            {
                return Ok("No Data Saved");
            }
        }

        // PUT api/Products/5
        [ServiceFilter(typeof(ValidateModelAttribute))]
        [HttpPut("{productNbr}")]
        public async Task<IActionResult> Put(long productNbr, [FromBody] ProductDetails productDetails)
        {
            var product = await productService.UpdateProductDetailsAsync(productNbr, productDetails);
            if (product == 1)
            {
                return Ok(product);
            }
            else
            {
                return Ok("product not found");
            }
        }

        // DELETE api/Products/5
        [ServiceFilter(typeof(ValidateModelAttribute))]
        [HttpDelete("{productNbr}")]
        public async Task<IActionResult> Delete(long productNbr)
        {
            var product = await productService.Delete<ProductDetails>(productNbr);
            if (product == 1)
            {
                return Ok(product);
            }
            else
            {
                return Ok("No product found");
            }
        } 
        #endregion
    }
}
