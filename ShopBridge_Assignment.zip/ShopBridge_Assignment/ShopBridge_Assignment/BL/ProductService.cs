﻿using ShopBridge_Assignment.Constants;
using ShopBridge_Assignment.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_Assignment.BL
{
    public class ProductService : IProductService
    {
        private IRepository dbRepository;

        public ProductService(IRepository _dbRepository)
        {
            dbRepository = _dbRepository;
        }

        public List<E> GetAllProductDetails<E>() where E : class
        {
            IQueryable<E> Query = dbRepository.GetAll<E>();
            List<E> entityinfo = Query.ToList();
            return entityinfo;
        }
        public async Task<int> SaveProductDetailsAsync<E>(E entity) where E : class
        {
            typeof(E).GetProperty(DbConstants.CreatedOn).SetValue(entity, DateTime.Now);
            typeof(E).GetProperty(DbConstants.CreatedBy).SetValue(entity, DbConstants.Admin);
            typeof(E).GetProperty(DbConstants.UpdatedBy).SetValue(entity, DbConstants.Admin);
            typeof(E).GetProperty(DbConstants.UpdatedOn).SetValue(entity, DateTime.Now);
            typeof(E).GetProperty(DbConstants.ActiveInd).SetValue(entity, DbConstants.Yes);
            dbRepository.Insert<E>(entity);
            var saveProduct = await dbRepository.Save();
            return saveProduct;
        }

        public async Task<int> UpdateProductDetailsAsync<E>(long id, E newEntity) where E : class
        {
            dynamic oldEntity = dbRepository.GetById<E>(id);
            if (oldEntity != null)
            {
                typeof(E).GetProperty(DbConstants.UpdatedBy).SetValue(newEntity, DbConstants.Admin);
                typeof(E).GetProperty(DbConstants.UpdatedOn).SetValue(newEntity, DbConstants.UpdatedOn);
                typeof(E).GetProperty(DbConstants.ActiveInd).SetValue(newEntity, oldEntity.ActiveInd);
                dbRepository.UpdateEntity(oldEntity, newEntity);
                var saveProduct = await dbRepository.Save();
                return saveProduct;

            }
            else
            {
                return 0;
            }

        }

        public async Task<int> Delete<E>(long ProductNbr) where E : class
        {
            var oldEntity = dbRepository.GetById<E>(ProductNbr);
            var newEntity = oldEntity;
            typeof(E).GetProperty(DbConstants.UpdatedOn).SetValue(newEntity, DateTime.Now);
            typeof(E).GetProperty(DbConstants.UpdatedBy).SetValue(newEntity, DbConstants.Admin);
            typeof(E).GetProperty(DbConstants.ActiveInd).SetValue(newEntity, DbConstants.No);
            dbRepository.UpdateEntity(oldEntity, newEntity);
            var saveProduct = await dbRepository.Save();
            return saveProduct;
        }
    }
}
