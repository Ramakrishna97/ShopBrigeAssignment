﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_Assignment.BL
{
    public interface IProductService
    {
        List<E> GetAllProductDetails<E>() where E : class;
        Task<int> SaveProductDetailsAsync<E>(E entity) where E : class;
        Task<int> UpdateProductDetailsAsync<E>(long productNbr, E newEntity) where E : class;
        Task<int> Delete<E>(long productNbr) where E : class;
    }
}
