﻿using ShopBridge_Assignment.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_Assignment.Repository
{
    public class Repository : IRepository
    {
        readonly SqlDbContext dbContext;

        public Repository(SqlDbContext context)
        {
            dbContext = context;
        }

        public void Insert<E>(E entity) where E : class
        {
            dbContext.Set<E>().Add(entity);
        }
        public void Delete<E>(E entity) where E : class
        {
            dbContext.Set<E>().Remove(entity);
        }
        public IQueryable<E> GetAll<E>() where E : class
        {
            return dbContext.Set<E>();
        }

        public E GetById<E>(long id) where E : class
        {
            return dbContext.Set<E>().Find(id);
        }

        public void UpdateEntity<E>(E oldEntity, E newEntity) where E : class
        {
            dbContext.Entry(oldEntity).CurrentValues.SetValues(newEntity);
        }

        public async Task<int> Save()
        {
            Task<int> result;
            try
            {
                result = Task<int>.Factory.StartNew(() => dbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return await result;
        }

    }
}
