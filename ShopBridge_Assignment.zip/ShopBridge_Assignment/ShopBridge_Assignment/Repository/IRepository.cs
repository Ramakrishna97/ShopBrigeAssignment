﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_Assignment.Repository
{
    public interface IRepository
    {
        void Insert<E>(E entity) where E : class;
        void Delete<E>(E entity) where E : class;
        IQueryable<E> GetAll<E>() where E : class;
        E GetById<E>(long id) where E : class;
        Task<int> Save();
        void UpdateEntity<E>(E oldEntity, E newEntity) where E : class;
    }
}
